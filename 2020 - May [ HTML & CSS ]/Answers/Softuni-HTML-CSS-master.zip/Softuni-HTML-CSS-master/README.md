# Softuni-HTML-CSS

### [Course Certificate](https://softuni.bg/certificates/details/72596/03d5a725) (link includes pass mark and course curriculum)
