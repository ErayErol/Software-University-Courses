**HTML-and-CSS-Softuni**

Exercises, HTML and CSS course at SoftUni, May 2019
