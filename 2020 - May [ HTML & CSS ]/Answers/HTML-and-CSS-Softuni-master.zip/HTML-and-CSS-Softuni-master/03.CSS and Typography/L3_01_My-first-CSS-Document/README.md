# 01 - My First CSS Document
------
Problems for in-class lab for the [�HTML & CSS�](https://softuni.bg/trainings/2375/html-and-css-may-2019) course @ **SoftUni**.

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/1234/CSS-Typography).

### Constraints
 * Create **"index.html"** and **"style.css"** files
 * Change the document **title** to **My First CSS Document**
 * Use **h1** and **h2** tags for headings
 * Use background with color - **rgb(51, 102, 153)**
 * Use white color for text