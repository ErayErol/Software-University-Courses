# 03 - Single Article Page 
------
Problems for in-class lab for the [“Web Fundamentals - HTML 5”](https://softuni.bg/trainings/2265/web-fundamentals-html5-january-2019/) course @ **SoftUni**.

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/1136/Introduction-to-HTML-and-CSS).

## Constraints
 * Change the document **title** to *Single Article Page*
 * Create an **article** with several items inside
	* Use **h2** and **h4** tags for headings
	* Use **p** tags for the text
	* Use **img** tag for the photo