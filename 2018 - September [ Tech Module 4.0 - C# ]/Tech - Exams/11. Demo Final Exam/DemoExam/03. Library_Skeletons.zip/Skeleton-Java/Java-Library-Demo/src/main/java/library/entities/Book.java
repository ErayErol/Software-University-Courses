package library.entities;

import javax.persistence.*;

@Entity
@Table(name = "books")
public class Book {
   //TODO
}
