package library.bindingModels;

public class BookBindingModel {
   //TODO
}
