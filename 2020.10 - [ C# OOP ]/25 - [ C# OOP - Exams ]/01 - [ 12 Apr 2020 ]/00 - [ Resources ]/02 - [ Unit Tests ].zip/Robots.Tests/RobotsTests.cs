﻿namespace Robots.Tests
{
    using System;

    public class RobotsTests
    {
    }
}
