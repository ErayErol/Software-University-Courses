using NUnit.Framework;

namespace Store.Tests
{
    public class StoreManagerTests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void TestOne()
        {
           Assert.Pass();
        }
    }
}