﻿using System;

namespace _04.CookiesProblem
{
    public class CookiesProblem
    {
        public int Solve(int k, int[] cookies)
        {
            throw new NotImplementedException();
        }
    }
}
