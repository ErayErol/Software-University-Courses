﻿namespace RobotService.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}