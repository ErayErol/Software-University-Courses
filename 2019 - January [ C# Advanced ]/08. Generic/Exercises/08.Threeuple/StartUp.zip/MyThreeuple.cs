﻿namespace _08.Threeuple
{
    using System;
    using System.Text;

    public class MyThreeuple<K, V, P>
    {
        public MyThreeuple(K item1, V item2, P item3)
        {
            this.Item1 = item1;
            this.Item2 = item2;
            this.Item3 = item3;
        }

        public K Item1 { get; set; }

        public V Item2 { get; set; }

        public P Item3 { get; set; }

        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.AppendLine($"{this.Item1} -> {this.Item2} -> {this.Item3}");

            var result = sb.ToString().TrimEnd();
            return result;
        }
    }
}