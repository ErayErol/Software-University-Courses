﻿namespace _03.GenericSwapMethodString
{
    using System.Collections.Generic;
    using System.Text;

    public class Box<T>
    {
        public Box()
        {
            this.Values = new List<T>();
        }

        public List<T> Values { get; set; }

        public void Swap(int firstIndex, int secondIndex)
        {
            var temp = this.Values[firstIndex];
            this.Values[firstIndex] = this.Values[secondIndex];
            this.Values[secondIndex] = temp;
        }

        public override string ToString()
        {
            var result = new StringBuilder();

            foreach (var item in this.Values)
            {
                result.AppendLine($"{item.GetType()}: {item}");
            }
            return result.ToString().TrimEnd();
        }
    }
}