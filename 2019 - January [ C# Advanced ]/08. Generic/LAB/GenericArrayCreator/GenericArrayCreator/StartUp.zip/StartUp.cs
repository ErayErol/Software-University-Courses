﻿namespace GenericArrayCreator
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var a = ArrayCreator.Create(10, 10);
            var b = ArrayCreator.Create(10, 33);
        }
    }
}