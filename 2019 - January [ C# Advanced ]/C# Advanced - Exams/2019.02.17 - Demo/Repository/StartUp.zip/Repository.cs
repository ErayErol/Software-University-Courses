﻿namespace Repository
{
    using System.Collections.Generic;

    public class Repository
    {
        //Write a C# class Repository that has data field, which stores entities).
        //All entities inside the repository have the same properties(в случая => Person) and a unique ID, that is assigned when they are added starting from zero.

        // Entity имаме предвид Person-и
        // правам следното => privite List<Person> people;

        // Тези Entity-та (Person-и) трябва да имат :
        // unique ID => което стартира от 0

        // След като вече имаме и ID => List<Person> не ни върши работа
        // защото трябва да ползваме и ID
        // затова правим => речник с ключ(ID) и стойност(Person)

        private Dictionary<int, Person> people;
        private int id;

        // The class constructor should initialize the data with a new Dictionary instance. Implement the following features:

        public Repository()
        {
            this.people = new Dictionary<int, Person>();
            this.id = 0;
        }

        // •	Getter Count – returns the number of stored entities

        public int Count
        {
            get => this.people.Count;
        }

        // •	Method Add(Person person) – adds an entity to the Data;
        // гледаме Method какво връща и по това решаваме дали е void или
        // Data означава текущият Repository с new Dictionary<int, Person>();

        public void Add(Person person)
        {
            this.people.Add(this.id, person);
            this.id++;
        }

        // •	Method Get(int id) – returns the entity(Person) with given ID

        public Person Get(int id)
        {
            return this.people[id];
        }

        // •	Method Update(int id(newID), Person newPerson) – replaces the entity(Person) with the given id(oldID) with the new entity(Person). Returns false if the id(oldID) doesn't exist, otherwise returns true.

        public bool Update(int id, Person newPerson)
        {
            if (this.people.ContainsKey(id) == false)
            {
                return false;
            }

            this.people[id] = newPerson;
            return true;
        }

        // •	Method Delete(id) – deletes an entity(Person) by given id(newID). Return false if the id(oldID) doesn't exist, otherwise return true.

        public bool Delete(int id)
        {
            if (this.people.ContainsKey(id) == false)
            {
                return false;
            }

            this.people.Remove(id);
            return true;
        }
    }
}