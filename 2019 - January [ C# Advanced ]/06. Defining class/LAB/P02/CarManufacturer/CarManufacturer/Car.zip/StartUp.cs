﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Car car = new Car();
            car.Make = "BMW";
            car.Model = "E92";
            car.Year = 2008;
            car.FuelQuantity = 100;
            car.FuelConsumption = 10;
            car.Drive(2);
            Console.WriteLine(car.WhoAmI());
        }
    }
}