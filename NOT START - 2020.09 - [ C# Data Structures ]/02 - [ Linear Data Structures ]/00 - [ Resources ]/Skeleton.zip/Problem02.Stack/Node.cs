﻿namespace Problem02.Stack
{
    public class Node<T>
    {
        // TODO: Implement
    }
}