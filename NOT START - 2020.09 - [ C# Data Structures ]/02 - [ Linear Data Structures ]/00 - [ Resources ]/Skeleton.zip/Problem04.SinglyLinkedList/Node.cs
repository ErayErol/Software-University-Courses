﻿namespace Problem04.SinglyLinkedList
{
    public class Node<T>
    {
        // TODO: Implement
    }
}