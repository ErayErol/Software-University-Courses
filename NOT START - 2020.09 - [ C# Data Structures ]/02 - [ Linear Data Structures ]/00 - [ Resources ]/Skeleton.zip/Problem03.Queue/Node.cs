﻿namespace Problem03.Queue
{
    public class Node<T>
    {
        // TODO: Implement
    }
}