﻿namespace CarDealer.Dtos.Import
{
    using System.Xml.Serialization;

    public class Supplier
    {
        [XmlElement("name")]
        public string Name { get; set; }

        [XmlElement("isImporter")]
        public bool IsImporter { get; set; }
    }
}
