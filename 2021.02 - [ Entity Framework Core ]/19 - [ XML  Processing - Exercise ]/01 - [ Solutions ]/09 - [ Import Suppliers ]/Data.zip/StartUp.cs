﻿namespace CarDealer
{
    using CarDealer.Data;
    using System;
    using System.IO;
    using System.Linq;
    using System.Xml.Serialization;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            var context = new CarDealerContext();
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            var inputXml = File.ReadAllText("../../../Datasets/suppliers.xml");
            var result = ImportSuppliers(context, inputXml);
            Console.WriteLine(result);
        }

        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            var serializer = new XmlSerializer(typeof(Dtos.Import.Supplier[]), new XmlRootAttribute("Suppliers"));
            var deserialized = (Dtos.Import.Supplier[])serializer.Deserialize(new StringReader(inputXml));
            Models.Supplier[] suppliers = deserialized
                .Select(x => new Models.Supplier()
                {
                    Name = x.Name,
                    IsImporter = x.IsImporter,
                }).ToArray();

            context.AddRange(suppliers);
            context.SaveChanges();
            var result = $"Successfully imported {suppliers.Length}";
            return result;
        }
    }
}