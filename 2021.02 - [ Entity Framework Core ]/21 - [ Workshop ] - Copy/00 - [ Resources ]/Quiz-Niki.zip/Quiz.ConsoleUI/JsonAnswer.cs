﻿namespace Quiz.ConsoleUI
{
    public class JsonAnswer
    {
        public string Answer { get; set; }

        public bool Correct { get; set; }
    }
}
