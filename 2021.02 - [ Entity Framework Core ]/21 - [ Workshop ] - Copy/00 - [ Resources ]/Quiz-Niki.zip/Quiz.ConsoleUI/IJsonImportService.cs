﻿namespace Quiz.ConsoleUI
{
    public interface IJsonImportService
    {
        void Import(string fileName, string quizName);
    }
}
