﻿namespace Quiz.Services.Models
{
    public class QuestionInputModel
    {
        public int QuestionId { get; set; }

        public int AnswerId { get; set; }
    }
}