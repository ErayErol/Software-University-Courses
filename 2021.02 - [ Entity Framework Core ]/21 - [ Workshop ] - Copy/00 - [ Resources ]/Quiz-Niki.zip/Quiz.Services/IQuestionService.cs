﻿namespace Quiz.Services
{
    public interface IQuestionService
    {
        int Add(string title, int quizId);
    }
}
