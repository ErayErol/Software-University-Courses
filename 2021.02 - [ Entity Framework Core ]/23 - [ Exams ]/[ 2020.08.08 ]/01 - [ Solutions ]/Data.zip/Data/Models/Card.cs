﻿namespace VaporStore.Data.Models
{
    using VaporStore.Data.Models.Enums;

    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class Card
    {
        public Card()
        {
            this.Purchases = new HashSet<Purchase>();
        }

        //[Key]
        public int Id { get; set; }

        [Required]
        //[RegularExpression(@"[\d]{4} [\d]{4} [\d]{4} [\d]{4}")]
        public string Number { get; set; }

        [Required]
        //[RegularExpression(@"[\d]{3}")]
        public string Cvc { get; set; }

        //[EnumDataType(typeof(CardType))]
        public CardType Type { get; set; }

        public int UserId { get; set; }
        public User User { get; set; }

        public ICollection<Purchase> Purchases { get; set; }
    }
}