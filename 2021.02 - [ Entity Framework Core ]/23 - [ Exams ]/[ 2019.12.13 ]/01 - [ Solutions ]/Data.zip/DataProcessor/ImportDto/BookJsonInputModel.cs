﻿namespace BookShop.DataProcessor.ImportDto
{
    public class BookJsonInputModel
    {
        public int? Id { get; set; }
    }
}