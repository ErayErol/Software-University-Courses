﻿using BookShop.Data.Models;
using BookShop.Data.Models.Enums;
using BookShop.DataProcessor.ImportDto;
using ProductShop.Utilities;

namespace BookShop.DataProcessor
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Xml.Serialization;
    using Data;
    using Newtonsoft.Json;
    using ValidationContext = System.ComponentModel.DataAnnotations.ValidationContext;

    public class Deserializer
    {
        private const string ErrorMessage = "Invalid data!";

        private const string SuccessfullyImportedBook
            = "Successfully imported book {0} for {1:F2}.";

        private const string SuccessfullyImportedAuthor
            = "Successfully imported author - {0} {1} with {2} books.";

        public static string ImportBooks(BookShopContext context, string xmlString)
        {
            const string root = "Books";
            var booksXml = XmlConverter.Deserializer<BookXmlInputModel>(xmlString, root);
            var sb = new StringBuilder();

            foreach (var xmlBook in booksXml)
            {
                var isValidDate = DateTime
                    .TryParseExact(xmlBook.PublishedOn, "MM/dd/yyyy",
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out var publishedOn);

                if (IsValid(xmlBook) == false || isValidDate == false)
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                var book = new Book
                {
                    Name = xmlBook.Name,
                    Price = xmlBook.Price,
                    Genre = (Genre)xmlBook.Genre,
                    Pages = xmlBook.Pages,
                    PublishedOn = publishedOn,
                };

                context.Books.Add(book);
                context.SaveChanges();
                sb.AppendLine(string.Format(SuccessfullyImportedBook, book.Name, book.Price));
            }

            var outputMsg = sb.ToString().TrimEnd();
            return outputMsg;
        }

        public static string ImportAuthors(BookShopContext context, string jsonString)
        {
            var authors = JsonConvert.DeserializeObject<AuthorJsonInputModel[]>(jsonString);
            var sb = new StringBuilder();
            foreach (var jsonAuthor in authors)
            {
                var email = context.Authors.FirstOrDefault(x => x.Email == jsonAuthor.Email);

                if (IsValid(jsonAuthor) == false ||
                    jsonAuthor.Books.Length == 0 ||
                    email != null)
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                var author = new Author()
                {
                    FirstName = jsonAuthor.FirstName,
                    LastName = jsonAuthor.LastName,
                    Phone = jsonAuthor.Phone,
                    Email = jsonAuthor.Email,
                };

                foreach (var jsonBook in jsonAuthor.Books)
                {
                    if (jsonBook.Id.HasValue)
                    {
                        var book = context.Books.FirstOrDefault(x => x.Id == jsonBook.Id.Value);
                        if (book != null)
                        {
                            author.AuthorsBooks.Add(new AuthorBook() { Book = book });
                        }
                    }
                }

                if (author.AuthorsBooks.Count == 0)
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                sb.AppendLine(string.Format(SuccessfullyImportedAuthor, author.FirstName, author.LastName, author.AuthorsBooks.Count));

                context.Authors.Add(author);
                context.SaveChanges();
            }

            var outputMsg = sb.ToString().TrimEnd();
            return outputMsg;
        }

        private static bool IsValid(object dto)
        {
            var validationContext = new ValidationContext(dto);
            var validationResult = new List<ValidationResult>();

            return Validator.TryValidateObject(dto, validationContext, validationResult, true);
        }
    }
}