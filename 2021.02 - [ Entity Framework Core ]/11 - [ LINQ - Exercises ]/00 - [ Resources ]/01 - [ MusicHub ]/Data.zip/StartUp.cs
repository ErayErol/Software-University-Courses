﻿namespace MusicHub
{
    using Data;
    using Initializer;
    using System;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        private const string NewLine = "\r\n";

        public static void Main(string[] args)
        {
            MusicHubDbContext context =
                new MusicHubDbContext();

            DbInitializer.ResetDatabase(context);

            var result = ExportSongsAboveDuration(context, 4);
            File.WriteAllText("../../../result.txt", result);
        }

        public static string ExportAlbumsInfo(MusicHubDbContext context, int producerId)
        {
            var albums = context
                .Albums
                .Where(album => album.ProducerId == producerId)
                .Select(album => new
                {
                    album.Name,
                    ReleseaDate = album.ReleaseDate
                        .ToString("MM/dd/yyyy", CultureInfo.InvariantCulture),
                    ProducerName = album.Producer.Name,
                    Songs = album.Songs
                        .Select(song => new
                        {
                            song.Name,
                            song.Price,
                            WriterName = song.Writer.Name,
                        })
                        .OrderByDescending(s => s.Name)
                        .ThenBy(s => s.WriterName)
                        .ToList(),
                    Price = album.Songs
                        .Sum(song => song.Price),
                })
                .OrderByDescending(album => album.Price)
                .ToList();

            var sb = new StringBuilder();

            foreach (var album in albums)
            {
                sb.AppendLine($"-Name: {album.Name}{NewLine}" +
                              $"-ReleaseDate: {album.ReleseaDate}{NewLine}" +
                              $"-ProducerName: {album.ProducerName}{NewLine}" +
                              "-Songs:");

                foreach (var song in album.Songs)
                {
                    int songNumber = album.Songs.IndexOf(song);
                    sb.AppendLine($"---#{++songNumber}{NewLine}" +
                                  $"---Name: {song.Name}{NewLine}" +
                                  $"---Price: {song.Price:F2}{NewLine}" +
                                  $"---Writer: {song.WriterName}");
                }

                sb.AppendLine($"-Price: {album.Price:F2}");
            }

            var result = sb.ToString().TrimEnd();
            return result;
        }

        public static string ExportSongsAboveDuration(MusicHubDbContext context, int duration)
        {
            var songs = context
                .Songs
                .ToList()
                .Where(s => (int)s.Duration.TotalSeconds > duration)
                .Select(s => new
                {
                    s.Name,
                    PerformerFullName = s.SongPerformers
                        .Select(sp => sp.Performer.FirstName + " " + sp.Performer.LastName)
                        .FirstOrDefault(),
                    WriterName = s.Writer.Name,
                    AlbumProducerName = s.Album.Producer.Name,
                    s.Duration,
                })
                .OrderBy(s=>s.Name)
                .ThenBy(s=>s.WriterName)
                .ThenByDescending(s=>s.PerformerFullName)
                .ToList();

            var sb = new StringBuilder();
            foreach (var song in songs)
            {
                var songNumber = songs.IndexOf(song);
                sb.AppendLine($"-Song #{++songNumber}{NewLine}" +
                              $"---SongName: {song.Name}{NewLine}" +
                              $"---Writer: {song.WriterName}{NewLine}" +
                              $"---Performer: {song.PerformerFullName}{NewLine}" +
                              $"---AlbumProducer: {song.AlbumProducerName}{NewLine}" +
                              $"---Duration: {song.Duration:c}");
            }

            var result = sb.ToString().TrimEnd();
            return result;
        }
    }
}

/*
 You need to write method string ExportSongsAboveDuration(MusicHubDbContext context, int duration) 
in the StartUp class that receives Song duration (integer, in seconds). 
Export the songs which are above the given duration. 
For each Song, export its Name, Performer Full Name, Writer Name, Album Producer and Duration (in format("c")). 
Sort the Songs by their Name (ascending), by Writer (ascending) and by Performer (ascending).
 * -Song #1
   ---SongName: Away
   ---Writer: Norina Renihan
   ---Performer: Lula Zuan
   ---AlbumProducer: Georgi Milkov
   ---Duration: 00:05:35
   -Song #2
   ---SongName: Bentasil
   ---Writer: Mik Jonathan
   ---Performer: Zabrina Amor
   ---AlbumProducer: Dobromir Slavchev
   ---Duration: 00:04:03
   …
 */