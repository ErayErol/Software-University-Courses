﻿namespace CarDealer.DTO
{
    public class ImportSuppliersInputModel
    {
        public string Name { get; set; }

        public bool IsImporter { get; set; }
    }
}