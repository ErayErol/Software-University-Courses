const Lorem = () => {
    return <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores impedit eos facilis veritatis, earum, dolor placeat, natus cum accusamus nulla fugiat veniam minima repudiandae pariatur sapiente alias voluptates sunt adipisci?</p>
};

export default Lorem;

export const someValue = 'Pesho';