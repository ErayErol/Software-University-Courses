export default function() {
    return (
        <footer className="site-footer"><p>React App, All rights reserved &copy;</p></footer>
    );
};