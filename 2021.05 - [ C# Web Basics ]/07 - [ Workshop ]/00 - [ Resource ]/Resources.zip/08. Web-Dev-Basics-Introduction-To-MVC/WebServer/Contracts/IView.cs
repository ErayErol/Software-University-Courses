﻿namespace WebServer.Contracts
{
    public interface IView
    {
        string View();
    }
}
