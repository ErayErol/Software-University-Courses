1. Folder wwwroot is missing, because the path is too long and I can't save it.

2. If you want to add wwwroot folder go one step back "00 - [ Resources ]/03. Library_Skeletons"

3. Open zip file and you will see wwwroot folder, copy and paste here and start project.